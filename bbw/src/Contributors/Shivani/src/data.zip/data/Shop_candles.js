export const shop_candle= [{
    "pImg": "https://www.justmylook.com/images/yankee-candle-floral-candy-large-jar-candle-p13501-22316_medium.jpg",
    "category": "New Fragrance",
    "id":"sh20",
    "name": "Iced Lemon Pound Cake",
    "category1": "3-Wick Candle",
    "Amount": "2599",
    "Rating": "53",
    "dec":"What it smells like: strolling on the boardwalk, favorite summer treats in handFragrance notes: caramel-glazed popcorn, warm taffy-apples and salty sweet cream."
  }, {
    "pImg": "https://cdn.shopify.com/s/files/1/0555/2277/products/MiaraCandleS2_360x.jpg?v=1634124245",
    "category": "New!",
    "id":"sh21",
    "name": "Raspberry Mimosa",
    "category1": "Single Wick Candle",
    "Amount": "2599",
    "Rating": "5",
    "dec":"What it smells like: a double scoop of the perfect fruity summer treat Fragrance noes: sweet summer berries, golden waffle cone and creamy vanilla."
  }, {
    "pImg": "https://valiram.com/wp-content/uploads/2018/11/BLUEBERRY-SUGAR-3-Wick-Candle.jpg",
    "category": "New!",
    "id":"sh22",
    "name": "Strawberry Pound Cake" ,
    "category1": "3-Wick Candle",
    "Amount": "2369",
    "Rating": "13",
    "dec":"What it smells like: the sweet, frosty treat that brings you back to carefree days at the fair Fragrance notes: blue raspberry syrup, hint of cherry and scoop of shaved ice."
  }, {
    "pImg": "https://m.media-amazon.com/images/I/714U6ZhY++L._AC_SY606_.jpg",
    "category": "Online Exclusive",
    "id":"sh23",
    "name": "Honeysuckle & Peach Spritz",
    "category1": "Single Wick Candle",
    "Amount": "2587",
    "Rating": "5",
    "dec":"What it smells like: a creamy, coconutty cocktail you'd find at the swim-up bar Fragrance notes: coconut rum, crushed pineapple and sweet vanilla cream."
  }, {
    "pImg": "https://cdn-fsly.yottaa.net/5d669b394f1bbf7cb77826ae/www.bathandbodyworks.com/v~4b.216/dw/image/v2/BBDL_PRD/on/demandware.static/-/Sites-master-catalog/default/dw9f23f750/crop/026482403_crop.jpg?sw=500&sh=600&sm=fit&q=75&yocs=o_s__",
    "category": "Online Exclusive",
    "id":"sh24",
    "name": "Coastal Watermelon",
    "category1": "Single Wick Candle",
    "Amount": "2599",
    "Rating": "3",
    "dec":"What it smells like: a fresh, woodsy, coastal hideaway. Fragrance notes: seaside sandalwood, eucalyptus leaves and sweet orange zest"
  }, {
    "pImg": "https://cdn-fsly.yottaa.net/5d669b394f1bbf7cb77826ae/www.bathandbodyworks.com/v~4b.216/dw/image/v2/BBDL_PRD/on/demandware.static/-/Sites-master-catalog/default/dw9f23f750/crop/026482403_crop.jpg?sw=500&sh=600&sm=fit&q=75&yocs=o_s_",
    "category": "New",
    "id":"sh25",
    "name": "Fresh Cut Lilacs",
    "category1": "3-Wick Candle",
    "Amount": "2541",
    "Rating": "31",
    "dec":"What it smells like: diving into a fresh, floral underwater palace.Fragrance notes: coral waters, beach gardenia and red sandalwood"
  }, {
    "pImg": "https://cdn-fsly.yottaa.net/5d669b394f1bbf7cb77826ae/www.bathandbodyworks.com/v~4b.216/dw/image/v2/BBDL_PRD/on/demandware.static/-/Sites-master-catalog/default/dwc9985836/crop/026458601_crop.jpg?sw=500&sh=600&sm=fit&q=75&yocs=o_s_",
    "category": "Online Exclusive",
    "id":"sh25",
    "name": "Japanese Cherry Blossom",
    "category1": "Single Wick Candle",
    "Amount": "2541",
    "Rating": "46",
    "dec":"What it smells like: borrowing their flannel for a hike in the woods.Fragrance notes: rich mahogany, black teakwood, dark oak and frosted lavender"
  }, {
    "pImg": "https://cdn-fsly.yottaa.net/5d669b394f1bbf7cb77826ae/www.bathandbodyworks.com/v~4b.216/dw/image/v2/BBDL_PRD/on/demandware.static/-/Sites-master-catalog/default/dw2fb6a62e/crop/026468838_crop.jpg?sw=500&sh=600&sm=fit&q=75&yocs=o_s_",
    "category": "New",
    "id":"sh26",
    "name": "Waikiki Beach Coconut",
    "category1": "3-Wick Candle",
    "Amount": "3666",
    "Rating": "5",
    "dec":"What it smells like: standing in the middle of a lilac field on a cool spring morning. Fragrance notes: lilac bouquets, dewy greens and soft spring air"
  },{
    "pImg": "https://cdn-fsly.yottaa.net/5d669b394f1bbf7cb77826ae/www.bathandbodyworks.com/v~4b.216/dw/image/v2/BBDL_PRD/on/demandware.static/-/Sites-master-catalog/default/dw7ba36a12/hires/026441623_alt_1.jpg?sh=413&yocs=o_s_",
    "category": "New!",
    "id":"sh27",
    "name": "Champagne Toast",
    "category1": "Single Wick Candle",
    "Amount": "2699",
    "Rating": "1",
    "dec":"What it smells like: a very-berry take on a tangy classic. Fragrance notes: sweet strawberry puree, acai berries, fresh lemonade and sugar crystals"
  },{
    "pImg": "https://cdn-fsly.yottaa.net/5d669b394f1bbf7cb77826ae/www.bathandbodyworks.com/v~4b.216/dw/image/v2/BBDL_PRD/on/demandware.static/-/Sites-master-catalog/default/dwa5dea731/crop/026437366_crop.jpg?sw=500&sh=600&sm=fit&q=75&yocs=o_s_",
    "category": "New",
    "id":"sh28",
    "name": "Mahogany Teakwood",
    "category1": "Single Wick Candle",
    "Amount": "1999",
    "Rating": "9",
    "dec":"What it smells like: sweet, fruity, bright paradise in a glass. Fragrance notes: tropical berries, sweet pineapple and freshly juiced oranges"
  },{
    "pImg": "https://cdn-fsly.yottaa.net/5d669b394f1bbf7cb77826ae/www.bathandbodyworks.com/v~4b.216/dw/image/v2/BBDL_PRD/on/demandware.static/-/Sites-master-catalog/default/dwdfe0df3d/crop/026437376_crop.jpg?sw=500&sh=600&sm=fit&q=75&yocs=o_s_",
    "category": "New",
    "id":"sh29",
    "name": "Eucalyptus Spearmint",
    "category1": "Single Wick Candle",
    "Amount": "1559",
    "Rating": "43",
    "dec":"What it smells like: the sweet, airy treat you love.Fragrance notes: fresh strawberries, golden shortcake and whipped cream"
  },{
    "pImg": "https://cdn-fsly.yottaa.net/5d669b394f1bbf7cb77826ae/www.bathandbodyworks.com/v~4b.216/dw/image/v2/BBDL_PRD/on/demandware.static/-/Sites-master-catalog/default/dwfdf75f06/crop/026426977_crop.jpg?sw=500&sh=600&sm=fit&q=75&yocs=o_s_",
    "category": "New",
    "id":"sh30",
    "name": "Fresh Cut Lilacs",
    "category1": "Single Wick Candle",
    "Amount": "1750",
    "Rating": "7",
    "dec":"What it smells like: that iconic fruity cake served at summertime barbecues. Fragrance notes: red raspberries, ripe blueberries, whipped vanilla cream and soft white cake"
  },{
    "pImg": "https://cdn-fsly.yottaa.net/5d669b394f1bbf7cb77826ae/www.bathandbodyworks.com/v~4b.216/dw/image/v2/BBDL_PRD/on/demandware.static/-/Sites-master-catalog/default/dw257db0ed/crop/026480789_crop.jpg?sw=500&sh=600&sm=fit&q=75&yocs=o_s_",
    "category": "Lavender Vanilla",
    "id":"sh31",
    "name": "Single Wick Candle",
    "category1": "candle",
    "Amount": "1999",
    "Rating": "232",
    "dec":"What it smells like: sweet, fruity, bright paradise in a glass.Fragrance notes: tropical berries, sweet pineapple and freshly juiced oranges"
  },{
    "pImg": "https://cdn-fsly.yottaa.net/5d669b394f1bbf7cb77826ae/www.bathandbodyworks.com/v~4b.216/dw/image/v2/BBDL_PRD/on/demandware.static/-/Sites-master-catalog/default/dw018cbcb6/crop/026437372_crop.jpg?sw=500&sh=600&sm=fit&q=75&yocs=o_s_",
    "category": "New Fragrance",
    "id":"sh32",
    "name": "Pink Pineapple Sunrise",
    "category1": "Single Wick Candle",
    "Amount": "1499",
    "Rating": "70",
    "dec":"What it smells like: a very-berry take on a tangy classic. Fragrance notes: sweet strawberry puree, acai berries, fresh lemonade and sugar crystals"
  },{
    "pImg": "https://cdn-fsly.yottaa.net/5d669b394f1bbf7cb77826ae/www.bathandbodyworks.com/v~4b.216/dw/image/v2/BBDL_PRD/on/demandware.static/-/Sites-master-catalog/default/dw3a3f2729/crop/026448739_crop.jpg?sw=500&sh=600&sm=fit&q=75&yocs=o_s_",
    "category": "New Fragrance",
    "id":"sh33",
    "name": "Iced Lemon Pound Cake",
    "category1": "Single Wick Candle",
    "Amount": "8566",
    "Rating": "58",
    "dec":"What it smells like: standing in the middle of a lilac field on a cool spring morning.Fragrance notes: lilac bouquets, dewy greens and soft spring air"
  },{
    "pImg": "https://cdn-fsly.yottaa.net/5d669b394f1bbf7cb77826ae/www.bathandbodyworks.com/v~4b.216/dw/image/v2/BBDL_PRD/on/demandware.static/-/Sites-master-catalog/default/dw536b669c/crop/026480791_crop.jpg?sw=500&sh=600&sm=fit&q=75&yocs=o_s_",
    "category": "New",
    "id":"sh34",
    "name": "Water Globe Pineapple",
    "category1": "3-Wick Candle Holder",
    "Amount": "999",
    "Rating": "5",
    "dec":"What it smells like: borrowing their flannel for a hike in the woods. Fragrance notes: rich mahogany, black teakwood, dark oak and frosted lavender"
  },{
    "pImg": "https://cdn-fsly.yottaa.net/5d669b394f1bbf7cb77826ae/www.bathandbodyworks.com/v~4b.216/dw/image/v2/BBDL_PRD/on/demandware.static/-/Sites-master-catalog/default/dw49cac0a3/crop/026413479_crop.jpg?sw=500&sh=600&sm=fit&q=75&yocs=o_s_",
    "category": "Just Added!",
    "id":"sh35",
    "name": "The Perfect Summer",
    "category1": "Single Wick Candle",
    "Amount": "1699",
    "Rating": "3",
    "dec":"What it smells like: diving into a fresh, floral underwater palace. Fragrance notes: coral waters, beach gardenia and red sandalwood"
  },{
    "pImg": "https://cdn-fsly.yottaa.net/5d669b394f1bbf7cb77826ae/www.bathandbodyworks.com/v~4b.216/dw/image/v2/BBDL_PRD/on/demandware.static/-/Sites-master-catalog/default/dw02c8940e/crop/026517154_crop.jpg?sw=500&sh=600&sm=fit&q=75&yocs=o_s_",
    "category": "New!",
    "id":"sh36",
    "name": "Strawberry Pound Cake",
    "category1": "Single Wick Candle",
    "Amount": "1455",
    "Rating": "1",
    "dec":"What it smells like: a fresh, woodsy, coastal hideaway. Fragrance notes: seaside sandalwood, eucalyptus leaves and sweet orange zest"
  },
  {
    "pImg": "https://www.justmylook.com/images/yankee-candle-floral-candy-large-jar-candle-p13501-22316_medium.jpg",
    "category": "New Fragrance",
    "id":"sh20",
    "name": "Iced Lemon Pound Cake",
    "category1": "3-Wick Candle",
    "Amount": "2599",
    "Rating": "53",
    "dec":"What it smells like: a creamy, coconutty cocktail you'd find at the swim-up bar Fragrance notes: coconut rum, crushed pineapple and sweet vanilla cream."
  }, {
    "pImg": "https://cdn.shopify.com/s/files/1/0555/2277/products/MiaraCandleS2_360x.jpg?v=1634124245",
    "category": "New!",
    "id":"sh21",
    "name": "Raspberry Mimosa",
    "category1": "Single Wick Candle",
    "Amount": "2599",
    "Rating": "5",
    "dec":"What it smells like: the sweet, frosty treat that brings you back to carefree days at the fair Fragrance notes: blue raspberry syrup, hint of cherry and scoop of shaved ice."
  
  },
  {
    "pImg": "https://cdn-fsly.yottaa.net/5d669b394f1bbf7cb77826ae/www.bathandbodyworks.com/v~4b.216/dw/image/v2/BBDL_PRD/on/demandware.static/-/Sites-master-catalog/default/dw257db0ed/crop/026480789_crop.jpg?sw=500&sh=600&sm=fit&q=75&yocs=o_s_",
    "category": "Lavender Vanilla",
    "id":"sh31",
    "name": "Single Wick Candle",
    "category1": "candle",
    "Amount": "1999",
    "Rating": "232",
    "dec":"What it smells like: a double scoop of the perfect fruity summer treat Fragrance noes: sweet summer berries, golden waffle cone and creamy vanilla."
  },{
    "pImg": "https://cdn-fsly.yottaa.net/5d669b394f1bbf7cb77826ae/www.bathandbodyworks.com/v~4b.216/dw/image/v2/BBDL_PRD/on/demandware.static/-/Sites-master-catalog/default/dw018cbcb6/crop/026437372_crop.jpg?sw=500&sh=600&sm=fit&q=75&yocs=o_s_",
    "category": "New Fragrance",
    "id":"sh32",
    "name": "Pink Pineapple Sunrise",
    "category1": "Single Wick Candle",
    "Amount": "1499",
    "Rating": "70",
    "dec":"What it smells like: strolling on the boardwalk, favorite summer treats in hand Fragrance notes: caramel-glazed popcorn, warm taffy-apples and salty sweet cream."
  
  }]