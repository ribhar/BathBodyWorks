 export const shop_body= [{
    "pImg": "https://cdn-fsly.yottaa.net/5d669b394f1bbf7cb77826ae/www.bathandbodyworks.com/v~4b.216/dw/image/v2/BBDL_PRD/on/demandware.static/-/Sites-master-catalog/default/dwf97a6473/crop/026414639_crop.jpg?sw=500&sh=600&sm=fit&q=75&yocs=o_s_1",
    "category": "New Fragrance",
    "id":"shi1",
    "name": "Butterfly",
    "category1": "Fine Fragrance Mist",
    "Amount": "17.50",
    "Rating": "53",
    "dec":"What it smells like: an inspiring flight through sweet, floral spring air Fragrance notes: raspberry nectar, iris petals and airy vanilla."

    
  }, {
    "pImg": "https://cdn-fsly.yottaa.net/5d669b394f1bbf7cb77826ae/www.bathandbodyworks.com/v~4b.216/dw/image/v2/BBDL_PRD/on/demandware.static/-/Sites-master-catalog/default/dwe52c7f04/crop/026403504_crop.jpg?sw=500&sh=600&sm=fit&q=75&yocs=o_s_",
    "category": "New Fragrance",
    "id":"shi2",
    "name": "Sandalwood Eucalyptus",
    "category1": "Body Wash and Foam Bath",
    "Amount": "15.50",
    "Rating": "5",
    "dec":"What it smells like: a tropical, calming aroma oasis   Fragrance notes: sandalwood, eucalyptus and mandarin essential oils"

  
  }, {
    "pImg": "https://cdn-fsly.yottaa.net/5d669b394f1bbf7cb77826ae/www.bathandbodyworks.com/v~4b.216/dw/image/v2/BBDL_PRD/on/demandware.static/-/Sites-master-catalog/default/dwff743235/crop/026438530_crop.jpg?sw=500&sh=600&sm=fit&q=75&yocs=o_s_",
    "category": "New!",
    "id":"shi3",
    "name": "Japenese Cherry Bolossom" ,
    "category1": "Ultimate Hydration Body Cream",
    "Amount": "15.50",
    "Rating": "5",
    "dec":"What it smells like: the fragrance equivalent of your little black dress—beautiful, timeless and undeniably feminine  Fragrance notes: Japanese cherry blossom, Asian pear, fresh mimosa petals, white jasmine and blushing sandalwood"

   
  }, {
    "pImg": "https://cdn-fsly.yottaa.net/5d669b394f1bbf7cb77826ae/www.bathandbodyworks.com/v~4b.216/dw/image/v2/BBDL_PRD/on/demandware.static/-/Sites-master-catalog/default/dwba77ffbc/crop/026267868_crop.jpg?sw=500&sh=600&sm=fit&q=75&yocs=o_s_",
    "category": "Ocean",
    "id":"shi4",
    "name": " Body Spray",
    "category1": "null",
    "Amount": "13.50",
    "Rating": "5",
    "dec":"What it smells like: a cool, rejuvenating lake swim in the Alps Fragrance notes: Italian bergamot, mountain spring water and oakmoss"

    
  }, {
    "pImg": "https://cdn-fsly.yottaa.net/5d669b394f1bbf7cb77826ae/www.bathandbodyworks.com/v~4b.216/dw/image/v2/BBDL_PRD/on/demandware.static/-/Sites-master-catalog/default/dw81522767/crop/026401914_crop.jpg?sw=500&sh=600&sm=fit&q=75&yocs=o_s_",
    "category": "New Fragrance",
    "id":"shi5",
    "name": "Pineapple Lime Eucalyptus",
    "category1": "Essential Oil Mist",
    "Amount": "%15.50",
    "Rating": "2",
    "dec":"What it smells like: the fragrance equivalent of your little black dress—beautiful, timeless and undeniably feminine  Fragrance notes: Japanese cherry blossom, Asian pear, fresh mimosa petals, white jasmine and blushing sandalwood"
  }, {
    "pImg": "https://cdn-fsly.yottaa.net/5d669b394f1bbf7cb77826ae/www.bathandbodyworks.com/v~4b.216/dw/image/v2/BBDL_PRD/on/demandware.static/-/Sites-master-catalog/default/dweccfb026/crop/026451873_crop.jpg?sw=500&sh=600&sm=fit&q=75&yocs=o_s_",
    "category": "New",
    "id":"shi6",
    "name": "White Tea Sage",
    "category1": "Shower Gel",
    "Amount": "13.50",
    "Rating": "3",
    "dec":" What it smells like: a tropical, calming aroma oasis  Fragrance notes: sandalwood, eucalyptus and mandarin essential oils"
  }, {
    "pImg": "https://cdn-fsly.yottaa.net/5d669b394f1bbf7cb77826ae/www.bathandbodyworks.com/v~4b.216/dw/image/v2/BBDL_PRD/on/demandware.static/-/Sites-master-catalog/default/dw65573859/crop/026451884_crop.jpg?sw=500&sh=600&sm=fit&q=75&yocs=o_s_",
    "category": "New Fragrance",
    "id":"shi7",
    "name": "Buttercups And Berry Bellin",
    "category1": "Fine Fragance And Mist",
    "Amount": "15.50",
    "Rating": "46",
    "dec":"What it smells like: the fragrance equivalent of your little black dress—beautiful, timeless and undeniably feminine  Fragrance notes: Japanese cherry blossom, Asian pear, fresh mimosa petals, white jasmine and blushing sandalwood"
  }, {
    "pImg": "https://cdn-fsly.yottaa.net/5d669b394f1bbf7cb77826ae/www.bathandbodyworks.com/v~4b.216/dw/image/v2/BBDL_PRD/on/demandware.static/-/Sites-master-catalog/default/dwbfc18541/crop/026401907_crop.jpg?sw=500&sh=600&sm=fit&q=75&yocs=o_s_",
    "category": "New Fragrance",
    "id":"shi8",
    "name": "Hibiscus Mandrine Violet",
    "category1": "Ultimate Hydration Body Cream",
    "Amount": "17.50",
    "Rating": "5",
    "dec":"What it smells like: the fragrance equivalent of your little black dress—beautiful, timeless and undeniably feminine  Fragrance notes: Japanese cherry blossom, Asian pear, fresh mimosa petals, white jasmine and blushing sandalwood"
  },{
    "pImg": "https://cdn-fsly.yottaa.net/5d669b394f1bbf7cb77826ae/www.bathandbodyworks.com/v~4b.216/dw/image/v2/BBDL_PRD/on/demandware.static/-/Sites-master-catalog/default/dw50a09db0/crop/026395407_crop.jpg?sw=500&sh=600&sm=fit&q=75&yocs=o_s_",
    "category": "New!",
    "id":"shi9",
    "name": "Fresh Water",
    "category1": "3-in-1 Hair , Face and Body Wash",
    "Amount": "14.50",
    "Rating": "1",
    "dec":"What it smells like: the sweet, airy treat you love Fragrance notes: fresh strawberries, golden shortcake and whipped cream"
  },{
    "pImg": "https://cdn-fsly.yottaa.net/5d669b394f1bbf7cb77826ae/www.bathandbodyworks.com/v~4b.216/dw/image/v2/BBDL_PRD/on/demandware.static/-/Sites-master-catalog/default/dwd097b2cd/crop/026451889_crop.jpg?sw=500&sh=600&sm=fit&q=75&yocs=o_s_",
    "category": "New Fragrance",
    "id":"shi10",
    "name": "Honey Suckle And Peach Spritz",
    "category1": "Ultimate Hydration Body Cream",
    "Amount": "15.50",
    "Rating": "9",
    "dec":"Fragrance notes: Italian bergamot, mountain spring water and oakmoss"
  },{
    "pImg": "https://cdn-fsly.yottaa.net/5d669b394f1bbf7cb77826ae/www.bathandbodyworks.com/v~4b.216/dw/image/v2/BBDL_PRD/on/demandware.static/-/Sites-master-catalog/default/dwc02b92b6/crop/026381189_crop.jpg?sw=500&sh=600&sm=fit&q=75&yocs=o_s_",
    "category": "New Fragrance",
    "id":"shi11",
    "name": "Coco Rose",
    "category1": "Body Wash And Foam Bath",
    "Amount": "15.50",
    "Rating": "43",
    "dec":"What it smells like: a fruity, sparkling drink in one hand and a sweet spring bouquet in the other   Fragrance notes: honeysuckle blooms, juicy peaches and orange zest."

  
  },{
    "pImg": "https://cdn-fsly.yottaa.net/5d669b394f1bbf7cb77826ae/www.bathandbodyworks.com/v~4b.216/dw/image/v2/BBDL_PRD/on/demandware.static/-/Sites-master-catalog/default/dwbfc18541/crop/026401907_crop.jpg?sw=500&sh=600&sm=fit&q=75&yocs=o_s_",
    "category": "Strawberry Pound Cake",
    "id":"shi12",
    "name": "Fine Fragrance Mist",
    "category1": "null",
    "Amount": "17.50",
    "Rating": "558",
    "dec":"What it smells like: the fragrance equivalent of your little black dress—beautiful, timeless and undeniably feminine  Fragrance notes: Japanese cherry blossom, Asian pear, fresh mimosa petals, white jasmine and blushing sandalwood"
  },{
    "pImg": "https://cdn-fsly.yottaa.net/5d669b394f1bbf7cb77826ae/www.bathandbodyworks.com/v~4b.216/dw/image/v2/BBDL_PRD/on/demandware.static/-/Sites-master-catalog/default/dw50a09db0/crop/026395407_crop.jpg?sw=500&sh=600&sm=fit&q=75&yocs=o_s_",
    "category": "New Fragrance",
    "id":"shi13",
    "name": "Lavender Mint Tea",
    "category1": "Ultimate Hydration Body Cream",
    "Amount": "17.50",
    "Rating": "15",
    "dec":"What it smells like: a fruity, sparkling drink in one hand and a sweet spring bouquet in the other   Fragrance notes: honeysuckle blooms, juicy peaches and orange zest."
  },{
    "pImg": "https://cdn-fsly.yottaa.net/5d669b394f1bbf7cb77826ae/www.bathandbodyworks.com/v~4b.216/dw/image/v2/BBDL_PRD/on/demandware.static/-/Sites-master-catalog/default/dwd097b2cd/crop/026451889_crop.jpg?sw=500&sh=600&sm=fit&q=75&yocs=o_s_",
    "category": "Thousand Wishes",
    "id":"shi14",
    "name": "Super Smooth Body Lotion",
    "category1": "null",
    "Amount": "13.50",
    "Rating": "70",
    "dec":"What it smells like: the sweet, airy treat you love Fragrance notes: fresh strawberries, golden shortcake and whipped cream"
  },{
    "pImg": "https://cdn-fsly.yottaa.net/5d669b394f1bbf7cb77826ae/www.bathandbodyworks.com/v~4b.216/dw/image/v2/BBDL_PRD/on/demandware.static/-/Sites-master-catalog/default/dwbfc18541/crop/026401907_crop.jpg?sw=500&sh=600&sm=fit&q=75&yocs=o_s_",
    "category": "Strawberry Pound Cake",
    "id":"shi15",
    "name": "Fine Fragrance Mist",
    "category1": "null",
    "Amount": "17.50",
    "Rating": "558",
    "dec":"What it smells like: the sweet, airy treat you love Fragrance notes: fresh strawberries, golden shortcake and whipped cream"
  },{
    "pImg": "https://cdn-fsly.yottaa.net/5d669b394f1bbf7cb77826ae/www.bathandbodyworks.com/v~4b.216/dw/image/v2/BBDL_PRD/on/demandware.static/-/Sites-master-catalog/default/dwbfc18541/crop/026401907_crop.jpg?sw=500&sh=600&sm=fit&q=75&yocs=o_s_",
    "category": "New Fragrance",
    "id":"shi16",
    "name": "Hibiscus Mandrine Violet",
    "category1": "Ultimate Hydration Body Cream",
    "Amount": "17.50",
    "Rating": "5",
    "dec":"What it smells like: a fruity, sparkling drink in one hand and a sweet spring bouquet in the other   Fragrance notes: honeysuckle blooms, juicy peaches and orange zest."
  },{
    "pImg": "https://cdn-fsly.yottaa.net/5d669b394f1bbf7cb77826ae/www.bathandbodyworks.com/v~4b.216/dw/image/v2/BBDL_PRD/on/demandware.static/-/Sites-master-catalog/default/dweccfb026/crop/026451873_crop.jpg?sw=500&sh=600&sm=fit&q=75&yocs=o_s_",
    "category": "New",
    "id":"shi17",
    "name": "White Tea Sage",
    "category1": "Shower Gel",
    "Amount": "13.50",
    "Rating": "3",
    "dec":"What it smells like: the sweet, airy treat you love Fragrance notes: fresh strawberries, golden shortcake and whipped cream"
  },{
    "pImg": "https://cdn-fsly.yottaa.net/5d669b394f1bbf7cb77826ae/www.bathandbodyworks.com/v~4b.216/dw/image/v2/BBDL_PRD/on/demandware.static/-/Sites-master-catalog/default/dw50a09db0/crop/026395407_crop.jpg?sw=500&sh=600&sm=fit&q=75&yocs=o_s_",
    "category": "New!",
    "id":"shi18",
    "name": "Fresh Water",
    "category1": "3-in-1 Hair , Face and Body Wash",
    "Amount": "14.50",
    "Rating": "1",
    "dec":"What it smells like: a fruity, sparkling drink in one hand and a sweet spring bouquet in the other   Fragrance notes: honeysuckle blooms, juicy peaches and orange zest."
  
  }]
 