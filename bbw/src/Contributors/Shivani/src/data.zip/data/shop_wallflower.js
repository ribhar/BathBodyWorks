export const shop_wallflower= [{
    "pImg": "https://cdn-fsly.yottaa.net/5d669b394f1bbf7cb77826ae/www.bathandbodyworks.com/v~4b.216/dw/image/v2/BBDL_PRD/on/demandware.static/-/Sites-master-catalog/default/dw3022bdd5/crop/026397324_crop.jpg?sw=500&sh=600&sm=fit&q=75&yocs=o_s_",
    "name":"Bubbly Rose Enhanced",
    "id":"shivani30",
    "category1": "Wallflowers Fragrance Refill",
    "Amount": "799",
    "Rating": "4",
    "dec":"What it smells like: that fruity red, white and blue popsicle you loved as a kid. Fragrance notes: red cherry, fresh citrus and juicy berry"

  }, {
    "pImg": "https://cdn-fsly.yottaa.net/5d669b394f1bbf7cb77826ae/www.bathandbodyworks.com/v~4b.216/dw/image/v2/BBDL_PRD/on/demandware.static/-/Sites-master-catalog/default/dw412c476c/crop/026399185_crop.jpg?sw=500&sh=600&sm=fit&q=75&yocs=o_s_",
    "name": "Fiji White Sands Enhanced",
    "id":"shivani31",
    "category1": "Wallflowers Fragrance Refil",
    "Amount": "699",
    "Rating": "5",
    "dec":"What it smells like: a sunny, happy, endlessly fun summer day. Fragrance notes: golden honeydew and bronzed vanilla."
    
  }, {
    "pImg": "https://cdn-fsly.yottaa.net/5d669b394f1bbf7cb77826ae/www.bathandbodyworks.com/v~4b.216/dw/image/v2/BBDL_PRD/on/demandware.static/-/Sites-master-catalog/default/dwf1c3d3c5/crop/026397334_crop.jpg?sw=500&sh=600&sm=fit&q=75&yocs=o_s_",
    "name": "Cinnamon Spiced Vanilla E" ,
    "id":"shivani32",
    "category1": "Wallflowers Fragrance Refill",
    "Amount": "799",
    "Rating": "3",
    "dec":"What it smells like: a sweet, refreshing celebration of pride, love and equality for all. Fragrance notes: sunny sangria, bright melon and misty waters."
  
  }, {
    "pImg": "https://cdn-fsly.yottaa.net/5d669b394f1bbf7cb77826ae/www.bathandbodyworks.com/v~4b.216/dw/image/v2/BBDL_PRD/on/demandware.static/-/Sites-master-catalog/default/dw3fabd454/crop/026400285_crop.jpg?sw=500&sh=600&sm=fit&q=75&yocs=o_s_",
    "name": " In the Stars",
    "id":"shivani33",
    "category1": "Wallflowers Fragrance Refill",
    "Amount": "799",
    "Rating": "1",
    "dec":"What it smells like: the perfect beach day (sand, sun, waves and all. Fragrance notes: white frangipani, toasted coconut and saltwater breeze"
  
  }, {
    "pImg": "https://cdn-fsly.yottaa.net/5d669b394f1bbf7cb77826ae/www.bathandbodyworks.com/v~4b.216/dw/image/v2/BBDL_PRD/on/demandware.static/-/Sites-master-catalog/default/dw08d8480a/crop/026438467_crop.jpg?sw=500&sh=600&sm=fit&q=75&yocs=o_s_",
    "name": "Sun-Drenched Linen",
    "id":"shivani34",
    "category1": "Wallflowers Fragrance Refill",
    "Amount": "899",
    "Rating": "5",
    "dec":"What it smells like: a cool, sweet breath of fresh air.Fragrance notes: fresh pine, juniper and juicy pear"
   
  }, {
    "pImg": "https://cdn-fsly.yottaa.net/5d669b394f1bbf7cb77826ae/www.bathandbodyworks.com/v~4b.216/dw/image/v2/BBDL_PRD/on/demandware.static/-/Sites-master-catalog/default/dwbc8dbe3b/crop/026394689_crop.jpg?sw=500&sh=600&sm=fit&q=75&yocs=o_s_",
    "name": "Gingham Love",
    "id":"shivani35",
    "category1": "Wallflowers Fragrance Refill",
    "Amount": "799",
    "Rating": "5",
    "dec":"What it smells like: strolling on the boardwalk, favorite summer treats in hand. Fragrance notes: caramel-glazed popcorn, warm taffy-apples and salty sweet cream."
   
  }, {
    "pImg": "https://cdn-fsly.yottaa.net/5d669b394f1bbf7cb77826ae/www.bathandbodyworks.com/v~4b.216/dw/image/v2/BBDL_PRD/on/demandware.static/-/Sites-master-catalog/default/dw911c291a/crop/026273224_crop.jpg?sw=500&sh=600&sm=fit&q=75&yocs=o_s_",
    "name": "Fresh Sheets",
    "id":"shivani36",
    "category1": "Wallflowers Fragrance Refill",
    "Amount": "800",
    "Rating": "2",
    "dec":"What it smells like: a refreshing sunny-day sip, equal parts tangy and sweet. Fragrance notes: tart orange juice, sweet pineapples and vanilla sugar cane."
  
  }, {
    "pImg": "https://cdn-fsly.yottaa.net/5d669b394f1bbf7cb77826ae/www.bathandbodyworks.com/v~4b.216/dw/image/v2/BBDL_PRD/on/demandware.static/-/Sites-master-catalog/default/dwdd602de9/crop/026194284_crop.jpg?sw=500&sh=600&sm=fit&q=75&yocs=o_s_",
    "name": "Hibiscus Mandrine Violet",
    "id":"shivani37",
    "category1": "Wallflowers Fragrance Refill",
    "Amount": "1750",
    "Rating": "4",
    "dec":"What it smells like: a sweet, sunny beach vacay. Fragrance notes: tropical white coconut, saltwater breezes and sun-bleached woods."
    
  },{
    "pImg": "https://cdn-fsly.yottaa.net/5d669b394f1bbf7cb77826ae/www.bathandbodyworks.com/v~4b.216/dw/image/v2/BBDL_PRD/on/demandware.static/-/Sites-master-catalog/default/dw93fdcecf/crop/026412381_crop.jpg?sw=500&sh=600&sm=fit&q=75&yocs=o_s_",
    "name": "Prosecco & Peaches",
    "id":"shivani38",
    "category1": "Wallflowers Fragrance Refill",
    "Amount": "1450",
    "Rating": "5",
    "dec":"What it smells like: a basket of laundry, fresh from the clothesline. Fragrance notes: fresh air, crisp eucalyptus and soft lavender."
    
  },{
    "pImg": "https://cdn-fsly.yottaa.net/5d669b394f1bbf7cb77826ae/www.bathandbodyworks.com/v~4b.216/dw/image/v2/BBDL_PRD/on/demandware.static/-/Sites-master-catalog/default/dwca05d7f2/crop/026412390_crop.jpg?sw=500&sh=600&sm=fit&q=75&yocs=o_s_",
    "name": "Wash & Fold",
    "id":"shivani39",
    "category1": "Wallflowers Fragrance Refill",
    "Amount": "899",
    "Rating": "4",
    "dec":"What it smells like: a sweet, sunny beach vacay.Fragrance notes: tropical white coconut, saltwater breezes and sun-bleached woods."
 
  },{
    "pImg": "https://cdn-fsly.yottaa.net/5d669b394f1bbf7cb77826ae/www.bathandbodyworks.com/v~4b.216/dw/image/v2/BBDL_PRD/on/demandware.static/-/Sites-master-catalog/default/dwce09b247/crop/026487220_crop.jpg?sw=500&sh=600&sm=fit&q=75&yocs=o_s_",
    "name": "Fresh Spring Morning",
    "id":"shivani40",
    "category1": "Wallflowers Fragrance Refill",
    "Amount": "785",
    "Rating": "3",
    "dec":"What it smells like: a refreshing sunny-day sip, equal parts tangy and sweet. Fragrance notes: tart orange juice, sweet pineapples and vanilla sugar cane."
   
  },{
    "pImg": "https://cdn-fsly.yottaa.net/5d669b394f1bbf7cb77826ae/www.bathandbodyworks.com/v~4b.216/dw/image/v2/BBDL_PRD/on/demandware.static/-/Sites-master-catalog/default/dwcff163db/crop/026358678_crop.jpg?sw=500&sh=600&sm=fit&q=75&yocs=o_s_",

    "name": "Mahogany Teakwood Increased Intensity",
    "id":"shivani41",
    "category1": "Wallflowers Fragrance Refill",
    "Amount": "750",
    "Rating": "2",
    "dec":"What it smells like: a soothing bedside bouquet. Fragrance notes: lavender blossom, creamy vanilla, white woods and sugared musk."
  
  },{
    "pImg": "https://cdn-fsly.yottaa.net/5d669b394f1bbf7cb77826ae/www.bathandbodyworks.com/v~4b.216/dw/image/v2/BBDL_PRD/on/demandware.static/-/Sites-master-catalog/default/dwa46718f9/crop/026397316_crop.jpg?sw=500&sh=600&sm=fit&q=75&yocs=o_s_",
   
    "name": "Fresh Cut Lilacs",
    "id":"shivani42",
    "category1": "Wallflowers Fragrance Refill",
    "Amount": "750",
    "Rating": "5",
    "dec":"What it smells like: a basket of laundry, fresh from the clothesline. Fragrance notes: fresh air, crisp eucalyptus and soft lavender."
  
  },{
    "pImg": "https://cdn-fsly.yottaa.net/5d669b394f1bbf7cb77826ae/www.bathandbodyworks.com/v~4b.216/dw/image/v2/BBDL_PRD/on/demandware.static/-/Sites-master-catalog/default/dwdc660c06/crop/026411736_crop.jpg?sw=500&sh=600&sm=fit&q=75&yocs=o_s_",
   
    "name": "Linen & Lavender",
    "id":"shivani43",
    "category1": "Wallflowers Fragrance Refill",
    "Amount": "750",
    "Rating": "4",
    "dec":"What it smells like: a soothing bedside bouquet.  Fragrance notes: lavender blossom, creamy vanilla, white woods and sugared musk."
  
  },{
    "pImg": "https://cdn-fsly.yottaa.net/5d669b394f1bbf7cb77826ae/www.bathandbodyworks.com/v~4b.216/dw/image/v2/BBDL_PRD/on/demandware.static/-/Sites-master-catalog/default/dwc0079183/crop/026421286_crop.jpg?sw=500&sh=600&sm=fit&q=75&yocs=o_s_",
    
    "name": "Pink Pineapple Sunrise",
    "id":"shivani44",
    "category1": "Wallflowers Fragrance Refill",
    "Amount": "750",
    "Rating": "4",
    "dec":"What it smells like: a bright, fruity ray of sunshine.  Fragrance notes: Sorrento lemons, citron and agave nectar."
  
  },{
    "pImg": "https://cdn-fsly.yottaa.net/5d669b394f1bbf7cb77826ae/www.bathandbodyworks.com/v~4b.216/dw/image/v2/BBDL_PRD/on/demandware.static/-/Sites-master-catalog/default/dw63552158/crop/026397341_crop.jpg?sw=500&sh=600&sm=fit&q=75&yocs=o_s_",
   
    "name": "Sun-Washed Citrus",
    "id":"shivani45",
    "category1": "Wallflowers Fragrance Refill",
    "Amount": "1750",
    "Rating": "4",
    "dec":"What it smells like: a basket of laundry, fresh from the clothesline. Fragrance notes: fresh air, crisp eucalyptus and soft lavender."
 
  },{
    "pImg": "https://cdn-fsly.yottaa.net/5d669b394f1bbf7cb77826ae/www.bathandbodyworks.com/v~4b.216/dw/image/v2/BBDL_PRD/on/demandware.static/-/Sites-master-catalog/default/dw888071ee/crop/026487227_crop.jpg?sw=500&sh=600&sm=fit&q=75&yocs=o_s_",
    "name": "Honeysuckle & Peach Spritz",
    "id":"shivani46",
    "category1": "Wallflowers Fragrance Refill",
    "Amount": "1350",
    "Rating": "4",
    "dec":"What it smells like: a bright, fruity ray of sunshine.  Fragrance notes: Sorrento lemons, citron and agave nectar."
  
  },{
    "pImg": "https://cdn-fsly.yottaa.net/5d669b394f1bbf7cb77826ae/www.bathandbodyworks.com/v~4b.216/dw/image/v2/BBDL_PRD/on/demandware.static/-/Sites-master-catalog/default/dw451170b1/crop/026397340_crop.jpg?sw=500&sh=600&sm=fit&q=75&yocs=o_s_",
    "name": "White Tea & Sage",
    "id":"shivani47",
    "category1": "Wallflowers Fragrance Refill",
    "Amount": "750",
    "Rating": "5",
    "dec":"What it smells like: a refreshing sunny-day sip, equal parts tangy and swee.Fragrance notes: tart orange juice, sweet pineapples and vanilla sugar cane."
  },
  {
    "pImg": "https://cdn-fsly.yottaa.net/5d669b394f1bbf7cb77826ae/www.bathandbodyworks.com/v~4b.216/dw/image/v2/BBDL_PRD/on/demandware.static/-/Sites-master-catalog/default/dw911c291a/crop/026273224_crop.jpg?sw=500&sh=600&sm=fit&q=75&yocs=o_s_",
    "name": "Fresh Sheets",
    "id":"shivani36",
    "category1": "Wallflowers Fragrance Refill",
    "Amount": "800",
    "Rating": "2",
    "dec":"What it smells like: strolling on the boardwalk, favorite summer treats in hand.  Fragrance notes: caramel-glazed popcorn, warm taffy-apples and salty sweet cream."
  
  }, {
    "pImg": "https://cdn-fsly.yottaa.net/5d669b394f1bbf7cb77826ae/www.bathandbodyworks.com/v~4b.216/dw/image/v2/BBDL_PRD/on/demandware.static/-/Sites-master-catalog/default/dwdd602de9/crop/026194284_crop.jpg?sw=500&sh=600&sm=fit&q=75&yocs=o_s_",
    "name": "Hibiscus Mandrine Violet",
    "id":"shivani37",
    "category1": "Wallflowers Fragrance Refill",
    "Amount": "1750",
    "Rating": "4",
    "dec":"What it smells like: a cool, sweet breath of fresh air. Fragrance notes: fresh pine, juniper and juicy pear"
    
  },
  {
    "pImg": "https://cdn-fsly.yottaa.net/5d669b394f1bbf7cb77826ae/www.bathandbodyworks.com/v~4b.216/dw/image/v2/BBDL_PRD/on/demandware.static/-/Sites-master-catalog/default/dw911c291a/crop/026273224_crop.jpg?sw=500&sh=600&sm=fit&q=75&yocs=o_s_",
    "name": "Fresh Sheets",
    "id":"shivani36",
    "category1": "Wallflowers Fragrance Refill",
    "Amount": "800",
    "Rating": "2",
    "dec":"What it smells like: the perfect beach day (sand, sun, waves and all.  Fragrance notes: white frangipani, toasted coconut and saltwater breez"
  
  }, {
    "pImg": "https://cdn-fsly.yottaa.net/5d669b394f1bbf7cb77826ae/www.bathandbodyworks.com/v~4b.216/dw/image/v2/BBDL_PRD/on/demandware.static/-/Sites-master-catalog/default/dwdd602de9/crop/026194284_crop.jpg?sw=500&sh=600&sm=fit&q=75&yocs=o_s_",
    "name": "Hibiscus Mandrine Violet",
    "id":"shivani37",
    "category1": "Wallflowers Fragrance Refill",
    "Amount": "1750",
    "Rating": "4",
    "dec":"What it smells like: a sweet, refreshing celebration of pride, love and equality for all. Fragrance notes: sunny sangria, bright melon and misty waters."
    
  },
  {
    "pImg": "https://cdn-fsly.yottaa.net/5d669b394f1bbf7cb77826ae/www.bathandbodyworks.com/v~4b.216/dw/image/v2/BBDL_PRD/on/demandware.static/-/Sites-master-catalog/default/dw412c476c/crop/026399185_crop.jpg?sw=500&sh=600&sm=fit&q=75&yocs=o_s_",
    "name": "Fiji White Sands Enhanced",
    "id":"shivani31",
    "category1": "Wallflowers Fragrance Refil",
    "Amount": "699",
    "Rating": "5",
    "dec":"What it smells like: a sunny, happy, endlessly fun summer day. Fragrance notes: golden honeydew and bronzed vanilla."
    
  }, {
    "pImg": "https://cdn-fsly.yottaa.net/5d669b394f1bbf7cb77826ae/www.bathandbodyworks.com/v~4b.216/dw/image/v2/BBDL_PRD/on/demandware.static/-/Sites-master-catalog/default/dwf1c3d3c5/crop/026397334_crop.jpg?sw=500&sh=600&sm=fit&q=75&yocs=o_s_",
    "name": "Cinnamon Spiced Vanilla E" ,
    "id":"shivani32",
    "category1": "Wallflowers Fragrance Refill",
    "Amount": "799",
    "Rating": "3",
    "dec":"What it smells like: that fruity red, white and blue popsicle you loved as a kid. Fragrance notes: red cherry, fresh citrus and juicy berry"
  
  }]